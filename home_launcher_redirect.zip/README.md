# Home Launcher Redirect - KernelSU Module

## 功能说明
这个 KernelSU 模块会在手机启动完成后自动启动指定的 Launcher：
`com.android.launcher/com.android.launcher.Launcher`

## 文件说明
- `module.prop` - 模块配置文件
- `service.sh` - 启动脚本，在系统启动完成后执行

## 安装方法
1. 将整个 `ks` 目录打包为 ZIP 文件
2. 打开 KernelSU Manager 应用
3. 点击右下角的 "+" 按钮
4. 选择刚才打包的 ZIP 文件
5. 等待安装完成
6. 重启设备

## 打包命令
在模块目录的上级目录执行：
```bash
cd D:\Code\Java-dev\home-launcher-redirect
zip -r home_launcher_redirect.zip ks/
```

或者在 Windows 上，右键 `ks` 目录，选择"发送到" -> "压缩(zipped)文件夹"

## 日志查看
模块会在 `/data/local/tmp/launcher_redirect.log` 记录启动日志。

查看日志命令：
```bash
adb shell cat /data/local/tmp/launcher_redirect.log
```

## 自定义
如果要启动其他 Launcher，请修改 `service.sh` 中的这一行：
```bash
am start -n com.android.launcher/com.android.launcher.Launcher
```
改为你想要的 Launcher 包名和 Activity 名称。

## 注意事项
- 需要已安装 KernelSU
- 确保目标 Launcher 已经安装在设备上
- `service.sh` 需要有执行权限（打包后自动处理）
